# -*- coding: utf-8 -*-
"""Single source of truth for application/update versions."""
from __future__ import annotations

APP_ID = "com.heattreatment.summarytool"
APP_TITLE = "热处理委托单汇总工具"
APP_VERSION = "0.12.7"
APP_VERSION_NAME = "真实在线自动更新测试版"
APP_VERSION_LABEL = f"v{APP_VERSION} {APP_VERSION_NAME}"
UPDATE_CHANNEL = "stable"
UPDATE_MANIFEST_SCHEMA_VERSION = 1
DATA_SCHEMA_VERSION = 1
BUILD_DATE = "2026-08-28"


def version_summary() -> dict[str, object]:
    return {
        "app_id": APP_ID,
        "title": APP_TITLE,
        "version": APP_VERSION,
        "version_name": APP_VERSION_NAME,
        "version_label": APP_VERSION_LABEL,
        "channel": UPDATE_CHANNEL,
        "manifest_schema_version": UPDATE_MANIFEST_SCHEMA_VERSION,
        "data_schema_version": DATA_SCHEMA_VERSION,
        "build_date": BUILD_DATE,
    }
